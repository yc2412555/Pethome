<template>
    <div>
      宠物驯养
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
