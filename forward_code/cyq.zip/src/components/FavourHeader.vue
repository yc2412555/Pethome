<template>
  <div>
      <mt-header title="宠友圈">
        <!-- <mt-button icon="back" slot="left">返回</mt-button> -->
        <!-- <mt-button icon="more" slot="right"></mt-button> -->
      </mt-header>
  </div>
</template>

<script>
export default {}
</script>

<style>
.mint-header {
  background-color: rgb(109, 235, 252);
}
</style>
