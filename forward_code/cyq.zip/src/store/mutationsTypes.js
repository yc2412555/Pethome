export const ADD_TO_LIKES = 'addToLikes'
export const ADD_TO_COLLECTION = 'addToCollection'