// export default {
//   isLiked (state) {
//     return state.likes.reduce((total, next) => {
//       if (next.isCheck) total.push(next)
//       return total
//     }, [])
//   }
// }
